create
    definer = root@localhost procedure PROC_CREATE_CATEGORY(IN categoryName varchar(50), IN status bit)
BEGIN
    INSERT INTO categorys(categoryName, status) VALUES (categoryName,status);
END;

